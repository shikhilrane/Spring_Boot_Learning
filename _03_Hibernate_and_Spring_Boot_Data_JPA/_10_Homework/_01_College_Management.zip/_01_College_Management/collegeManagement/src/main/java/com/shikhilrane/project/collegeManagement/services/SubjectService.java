package com.shikhilrane.project.collegeManagement.services;

public interface SubjectService {
}
