package com.shikhilrane.project.collegeManagement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdmissionRecordDto {
    private Long id;
    private Integer fees;
    private Long studentId;
}
